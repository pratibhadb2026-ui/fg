import React, { useState, useEffect } from 'react';
import { apiRequest } from '../utils/api.js';
import AttendanceProfiles from '../components/AttendanceProfiles.jsx';
import { useAuth } from '../context/AuthContext.jsx';
import { 
  Clock, 
  CheckCircle2, 
  XCircle, 
  ClipboardList, 
  Plus, 
  AlertCircle, 
  Award, 
  ToggleLeft, 
  ToggleRight,
  CalendarCheck,
  CheckCircle
} from 'lucide-react';

export default function SeniorDashboard({ activeTab }) {
  const { user } = useAuth();
  const [juniors, setJuniors] = useState([]);
  const [allMembers, setAllMembers] = useState([]);
  const [catBAttendance, setCatBAttendance] = useState([]);
  const [catAAttendance, setCatAAttendance] = useState([]);
  const coreMembers = allMembers.filter(u => u && u.role === 'cat_a');
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);

  // Feedback State
  const [feedback, setFeedback] = useState(null);

  // Time Window State
  const [bypassTimeCheck, setBypassTimeCheck] = useState(false);

  // New Task Form
  const [showAssignModal, setShowAssignModal] = useState(false);
  const [juniorSearch, setJuniorSearch] = useState('');
  const [groupTask, setGroupTask] = useState(null);
  const [taskEdit, setTaskEdit] = useState(null);
  const [taskEditForm, setTaskEditForm] = useState({status:'In Progress',progress:10,comment:''});
  const [newTask, setNewTask] = useState({
    title: '',
    description: '',
    assignedTo: '',
    assignedToIds: [],
    assignmentMode: 'individual',
    priority: 'Medium',
    deadline: new Date(Date.now() + 86400000 * 3).toISOString().split('T')[0]
  });

  useEffect(() => {
    fetchSeniorData();
  }, [activeTab]);

  const showFeedbackMsg = (msg, type = 'success') => {
    setFeedback({ msg, type });
    setTimeout(() => setFeedback(null), 5000);
  };

  const fetchSeniorData = async () => {
    setLoading(true);
    try {
      const allUsers = await apiRequest('/users');
      const safeUsers = Array.isArray(allUsers) ? allUsers.filter(Boolean) : [];
      const jrList = safeUsers.filter(u => u.role === 'cat_b');
      setAllMembers(safeUsers);
      setJuniors(jrList);

      const todayStr = new Date().toISOString().split('T')[0];
      const attData = await apiRequest(`/attendance?date=${todayStr}`);
      const safeAtt = Array.isArray(attData) ? attData : [];

      setCatBAttendance(safeAtt.filter(a => a && (a.category === 'Juniors' || a.category === 'B')));
      setCatAAttendance(safeAtt.filter(a => a && (a.category === 'Core' || a.category === 'A')));

      const tList = await apiRequest('/tasks');
      setTasks(Array.isArray(tList) ? tList : []);
    } catch (err) {
      console.error('Error fetching senior data:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleMarkCatB = async (userId, status) => {
    try {
      const res = await apiRequest('/attendance/mark-cat-b', 'POST', {
        userId,
        status
      });
      fetchSeniorData();
      showFeedbackMsg(`Junior attendance marked: ${status} at ${res.timeLogged || 'now'}`, 'success');
    } catch (err) {
      showFeedbackMsg('Attendance Marking Error: ' + err.message, 'error');
    }
  };

  const handleMarkCatA = async (userId, status) => {
    try {
      const res = await apiRequest('/attendance/mark-cat-a', 'POST', { userId, status });
      fetchSeniorData();
      showFeedbackMsg(`Core attendance marked: ${status} at ${res.timeLogged || 'now'}`, 'success');
    } catch (err) {
      showFeedbackMsg('Core attendance marking error: ' + err.message, 'error');
    }
  };

  const handleLeadershipTaskUpdate = async (e) => {
    e.preventDefault();
    if (!taskEdit) return;
    try {
      await apiRequest(`/tasks/${taskEdit.id}/status`, 'PUT', taskEditForm);
      setTaskEdit(null);
      fetchSeniorData();
      showFeedbackMsg('Task progress updated successfully.', 'success');
    } catch (err) {
      showFeedbackMsg('Task update error: ' + err.message, 'error');
    }
  };

  const handleAssignTask = async (e) => {
    e.preventDefault();
    const selectedIds = newTask.assignmentMode === 'group' ? newTask.assignedToIds : (newTask.assignedTo ? [newTask.assignedTo] : []);
    if (!newTask.title || !selectedIds.length) {
      showFeedbackMsg('Please enter task title and select at least one junior member.', 'error');
      return;
    }

    try {
      const created = await apiRequest('/tasks', 'POST', { ...newTask, assignedToIds: selectedIds });
      setShowAssignModal(false);
      setNewTask({
        title: '',
        description: '',
        assignedTo: '',
        assignedToIds: [],
        assignmentMode: 'individual',
        priority: 'Medium',
        deadline: new Date(Date.now() + 86400000 * 3).toISOString().split('T')[0]
      });
      fetchSeniorData();
      showFeedbackMsg(`🎯 Task "${created.title}" assigned successfully to ${created.assignedToName || 'Junior'}!`, 'success');
    } catch (err) {
      showFeedbackMsg('Task assignment error: ' + err.message, 'error');
    }
  };

  if (activeTab === 'attendance_profiles') return <AttendanceProfiles users={user?.role === 'president' ? allMembers : juniors} viewerRole={user?.role} />;

  return (
    <div className="space-y-6">
      {/* Feedback Banner */}
      {feedback && (
        <div className={`p-4 rounded-2xl text-sm font-bold flex items-center space-x-3 shadow-2xl border transition-all ${
          feedback.type === 'success' ? 'bg-emerald-600 text-white border-emerald-400' : 'bg-red-600 text-white border-red-400'
        }`}>
          {feedback.type === 'success' ? <CheckCircle className="w-6 h-6 shrink-0" /> : <AlertCircle className="w-6 h-6 shrink-0" />}
          <span>{feedback.msg}</span>
        </div>
      )}

      {/* TAB 1: MARK JUNIOR DAILY ATTENDANCE */}
      {(activeTab === 'cat_b_attendance' || activeTab === 'default' || !activeTab) && (
        <div className="glass-panel p-6 space-y-6">
          {/* Header */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
            <div>
              <h2 className="text-xl font-bold text-white flex items-center space-x-2">
                <Clock className="w-5 h-5 text-cyan-400" />
                <span>Junior Daily Attendance</span>
              </h2>
              <p className="text-xs text-slate-400 mt-1">Mark attendance for Juniors with arrival timestamp</p>
            </div>
          </div>

          {/* Junior Attendance List */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {juniors.map((jr) => {
              const attRecord = catBAttendance.find(a => a && (a.userId === jr.id || a.userUsername === jr.username));
              const status = attRecord ? attRecord.status : 'Not Marked';

              return (
                <div key={jr.id} className="glass-card p-4 rounded-2xl border border-slate-800 space-y-3 relative">
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="font-bold text-white text-sm">{jr.name}</div>
                      <div className="text-xs text-slate-400">{jr.designation}</div>
                      <div className="text-xs text-cyan-400 font-semibold mt-0.5">{jr.team}</div>
                    </div>
                    <span className={`px-2 py-0.5 rounded-full text-xs font-bold border ${
                      status === 'Present' ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30' :
                      status === 'Absent' ? 'bg-red-500/20 text-red-300 border-red-500/30' :
                      'bg-slate-800 text-slate-400 border-slate-700'
                    }`}>
                      {status}
                    </span>
                  </div>

                  {attRecord && status === 'Present' && (
                    <div className="text-xs text-emerald-400 bg-emerald-500/10 p-2 rounded-xl border border-emerald-500/20 font-mono">
                      Logged Present at: {attRecord.timeLogged}
                    </div>
                  )}

                  {/* Mark Action Buttons */}
                  <div className="flex items-center space-x-2 pt-2 border-t border-slate-800">
                    <button
                      onClick={() => handleMarkCatB(jr.id, 'Present')}
                      className={`flex-1 py-2 rounded-xl font-semibold text-xs transition-all flex items-center justify-center space-x-1 ${
                        status === 'Present'
                          ? 'bg-emerald-500 text-white shadow-lg'
                          : 'bg-slate-800 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/20'
                      }`}
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Present</span>
                    </button>

                    <button
                      onClick={() => handleMarkCatB(jr.id, 'Absent')}
                      className={`flex-1 py-2 rounded-xl font-semibold text-xs transition-all flex items-center justify-center space-x-1 ${
                        status === 'Absent'
                          ? 'bg-red-500 text-white shadow-lg'
                          : 'bg-slate-800 hover:bg-red-500/20 text-red-400 border border-red-500/20'
                      }`}
                    >
                      <XCircle className="w-3.5 h-3.5" />
                      <span>Absent</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 2: CORE TEAM ATTENDANCE — PRESIDENT MARKS DIRECTLY */}
      {user.role === 'president' && (activeTab === 'core_attendance' || activeTab === 'cat_a_approval') && (
        <div className="glass-panel p-6 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
            <div>
              <h2 className="text-xl font-bold text-white flex items-center space-x-2">
                <Award className="w-5 h-5 text-amber-400" />
                <span>Core Team Attendance</span>
              </h2>
              <p className="text-xs text-slate-400 mt-1">President directly marks Present or Absent attendance for every Core member.</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {coreMembers.map((member) => {
              const attRecord = catAAttendance.find(a => a && (a.userId === member.id || a.userUsername === member.username));
              const status = attRecord ? attRecord.status : 'Not Marked';
              return (
                <div key={member.id} className="glass-card p-4 rounded-2xl border border-slate-800 space-y-3 relative">
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="font-bold text-white text-sm">{member.name}</div>
                      <div className="text-xs text-slate-400">{member.designation}</div>
                      <div className="text-xs text-cyan-400 font-semibold mt-0.5">{member.team}</div>
                    </div>
                    <span className={`px-2 py-0.5 rounded-full text-xs font-bold border ${
                      status === 'Present' ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30' :
                      status === 'Absent' ? 'bg-red-500/20 text-red-300 border-red-500/30' :
                      'bg-slate-800 text-slate-400 border-slate-700'
                    }`}>{status}</span>
                  </div>
                  {attRecord && status === 'Present' && (
                    <div className="text-xs text-emerald-400 bg-emerald-500/10 p-2 rounded-xl border border-emerald-500/20 font-mono">
                      Logged Present at: {attRecord.timeLogged}
                    </div>
                  )}
                  <div className="flex items-center space-x-2 pt-2 border-t border-slate-800">
                    <button onClick={() => handleMarkCatA(member.id, 'Present')} className={`flex-1 py-2 rounded-xl font-semibold text-xs transition-all ${status === 'Present' ? 'bg-emerald-500 text-white shadow-lg' : 'bg-slate-800 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/20'}`}>Present</button>
                    <button onClick={() => handleMarkCatA(member.id, 'Absent')} className={`flex-1 py-2 rounded-xl font-semibold text-xs transition-all ${status === 'Absent' ? 'bg-red-500 text-white shadow-lg' : 'bg-slate-800 hover:bg-red-500/20 text-red-400 border border-red-500/20'}`}>Absent</button>
                  </div>
                  {attRecord?.presMarkedBy && <div className="text-[11px] text-amber-300">Marked by President: {attRecord.presMarkedBy}</div>}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 3: TASK ASSIGNMENT & TRACKING */}
      {(activeTab === 'task_assign' || activeTab === 'tasks_overview') && (
        <div className="glass-panel p-6 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
            <div>
              <h2 className="text-xl font-bold text-white flex items-center space-x-2">
                <ClipboardList className="w-5 h-5 text-cyan-400" />
                <span>Task Assignment & Status Tracking</span>
              </h2>
              <p className="text-xs text-slate-400 mt-1">Assign work to Juniors and monitor real-time progress updates</p>
            </div>
          </div>

          <div className="overflow-x-auto rounded-2xl border border-slate-800">
            <table className="w-full text-left text-xs">
              <thead>
                <tr>
                  <th>Task Title</th>
                  <th>Assigned To</th>
                  <th>Team</th>
                  <th>Priority</th>
                  <th>Status</th>
                  <th>Progress Bar</th>
                  <th>Deadline</th>
                </tr>
              </thead>
              <tbody>
                {tasks.map((task) => (
                  <tr key={task.id}>
                    <td className="font-bold text-white">
                      <div>{task.title}</div>
                      <div className="text-xs text-slate-400 font-normal">{task.description}</div>
                    </td>
                    <td className="font-medium text-slate-200">{task.isGroupTask && Array.isArray(task.groupMembers) ? (
                      <button
                        type="button"
                        onClick={()=>setGroupTask(task)}
                        className="font-bold rounded-lg px-2 py-1 text-left"
                        style={{background:'#0f2433',color:'#7dd3fc',border:'1px solid rgba(56,189,248,0.42)',display:'inline-block',lineHeight:'1.25'}}
                      >
                        👥 Group ({task.groupMembers.length}) · View Members
                      </button>
                    ) : task.assignedToName}</td>
                    <td className="text-slate-300">{task.team}</td>
                    <td>
                      <span className={`px-2 py-0.5 rounded text-xs font-bold ${
                        task.priority === 'Urgent' ? 'bg-red-500/20 text-red-300' :
                        task.priority === 'High' ? 'bg-amber-500/20 text-amber-300' :
                        'bg-blue-500/20 text-blue-300'
                      }`}>
                        {task.priority}
                      </span>
                    </td>
                    <td>
                      <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold border ${
                        task.status === 'Completed' ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30' :
                        task.status === 'In Progress' ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30' :
                        task.status === 'Accepted' ? 'bg-purple-500/20 text-purple-300 border-purple-500/30' :
                        'bg-slate-800 text-slate-400 border-slate-700'
                      }`}>
                        {task.status}
                      </span>
                    </td>
                    <td className="w-36">
                      <div className="flex items-center space-x-2">
                        <div className="w-full bg-slate-900 rounded-full h-2 overflow-hidden border border-slate-700">
                          <div
                            className="bg-cyan-500 h-full rounded-full transition-all duration-300"
                            style={{ width: `${task.progress}%` }}
                          ></div>
                        </div>
                        <span className="text-xs font-mono text-slate-300">{task.progress}%</span>
                      </div>
                    </td>
                    <td className="text-slate-300 font-mono">{task.deadline}{(((task.assignedTo===user?.id)||(task.assignedToUsername===user?.username)||(Array.isArray(task.groupMembers)&&task.groupMembers.some(m=>m.id===user?.id||m.username===user?.username))) && task.status!=='Completed') && <button type="button" onClick={()=>{setTaskEdit(task);setTaskEditForm({status:task.status||'Pending',progress:Number(task.progress||0),comment:''})}} className="ml-2 px-2 py-1 rounded-lg font-bold text-[10px]" style={{background:'#f59e0b',color:'#111827'}}>Update</button>}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {taskEdit && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80">
          <div className="glass-panel max-w-md w-full p-6 rounded-3xl border border-amber-500/30 shadow-2xl">
            <div className="flex items-start justify-between mb-4"><div><h3 className="text-lg font-bold text-white">Update Task Progress</h3><p className="text-xs text-amber-300 mt-1">{taskEdit.title}</p></div><button type="button" onClick={()=>setTaskEdit(null)} className="text-slate-400 hover:text-white text-xl">✕</button></div>
            <form onSubmit={handleLeadershipTaskUpdate} className="space-y-4">
              <div><label className="block text-xs text-slate-300 mb-1">Status</label><select value={taskEditForm.status} onChange={e=>setTaskEditForm({...taskEditForm,status:e.target.value})} className="w-full p-3 glass-input text-white"><option>Pending</option><option>Accepted</option><option>In Progress</option><option>Completed</option></select></div>
              <div><div className="flex justify-between text-xs text-slate-300 mb-1"><span>Completion</span><b className="text-cyan-300">{taskEditForm.progress}%</b></div><input type="range" min="0" max="100" value={taskEditForm.progress} onChange={e=>setTaskEditForm({...taskEditForm,progress:Number(e.target.value)})} className="w-full"/></div>
              <textarea rows="3" value={taskEditForm.comment} onChange={e=>setTaskEditForm({...taskEditForm,comment:e.target.value})} placeholder="Progress update / work note" className="w-full p-3 glass-input text-white"/>
              <div className="flex justify-end gap-2"><button type="button" onClick={()=>setTaskEdit(null)} className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300">Cancel</button><button type="submit" className="px-5 py-2 rounded-xl bg-amber-500 text-slate-950 font-extrabold">Save Update</button></div>
            </form>
          </div>
        </div>
      )}

      {groupTask && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="glass-panel max-w-md w-full p-6 rounded-3xl border border-cyan-500/30 shadow-2xl">
            <div className="flex items-start justify-between mb-4"><div><h3 className="text-lg font-bold text-white">Group Task Members</h3><p className="text-xs text-cyan-400 mt-1">{groupTask.title}</p></div><button onClick={()=>setGroupTask(null)} className="text-slate-400 hover:text-white text-xl">✕</button></div>
            <div className="space-y-2 max-h-72 overflow-y-auto">{(groupTask.groupMembers||[]).map(m=><div key={m.id||m.username} className="p-3 rounded-xl border border-slate-700 bg-slate-900/80"><div className="font-bold text-white">{m.name}</div><div className="text-xs text-slate-400">@{m.username} · {m.designation||'Team Member'}{m.team?` · ${m.team}`:''}</div></div>)}</div>
          </div>
        </div>
      )}

      {/* MODAL: ASSIGN TASK */}
      {showAssignModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80">
          <div className="glass-panel max-w-md w-full max-h-[90vh] overflow-y-auto p-6 shadow-2xl border border-slate-700">
            <h3 className="text-lg font-bold text-white mb-4">Assign Task to Junior Member</h3>
            <form onSubmit={handleAssignTask} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 mb-1 font-semibold">Task Title *</label>
                <input
                  type="text"
                  required
                  value={newTask.title}
                  onChange={(e) => setNewTask({ ...newTask, title: e.target.value })}
                  className="w-full p-2.5 glass-input text-white"
                  placeholder="e.g. Design Landing Page Banner"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1 font-semibold">Task Instructions / Description</label>
                <textarea
                  rows="3"
                  value={newTask.description}
                  onChange={(e) => setNewTask({ ...newTask, description: e.target.value })}
                  className="w-full p-2.5 glass-input text-white"
                  placeholder="Detailed work requirements..."
                ></textarea>
              </div>

              <div>
                <label className="block text-slate-300 mb-1 font-semibold">Assign to Junior Member(s) *</label>
                <div className="grid grid-cols-2 gap-2 mb-2">
                  <button type="button" onClick={()=>setNewTask({...newTask,assignmentMode:'individual',assignedTo:newTask.assignedToIds[0] || newTask.assignedTo,assignedToIds:newTask.assignedTo ? [newTask.assignedTo] : newTask.assignedToIds})} style={{background:newTask.assignmentMode==='individual'?'#06b6d4':'#1e293b',color:newTask.assignmentMode==='individual'?'#082f49':'#e2e8f0',borderColor:newTask.assignmentMode==='individual'?'#22d3ee':'#475569'}} className="py-2 rounded-xl border font-bold">Individual</button>
                  <button type="button" onClick={()=>setNewTask({...newTask,assignmentMode:'group',assignedTo:''})} style={{background:newTask.assignmentMode==='group'?'#06b6d4':'#1e293b',color:newTask.assignmentMode==='group'?'#082f49':'#e2e8f0',borderColor:newTask.assignmentMode==='group'?'#22d3ee':'#475569'}} className="py-2 rounded-xl border font-bold">Group Task</button>
                </div>
                <input value={juniorSearch} onChange={e=>setJuniorSearch(e.target.value)} placeholder={`Search Junior (${juniors.length} available)`} className="w-full p-2.5 glass-input text-white mb-2" />
                <div className="max-h-52 overflow-y-auto overscroll-contain rounded-xl border border-slate-800 bg-slate-950/70 p-2 space-y-1">
                  {juniors.filter(j=>`${j.name} ${j.username} ${j.designation||''} ${j.team||''}`.toLowerCase().includes(juniorSearch.toLowerCase())).map((jr)=>{
                    const selected = newTask.assignmentMode==='group' ? newTask.assignedToIds.includes(jr.id) : newTask.assignedTo===jr.id;
                    return <button type="button" key={jr.id} onClick={()=>{
                      if(newTask.assignmentMode==='group'){ const ids=newTask.assignedToIds.includes(jr.id)?newTask.assignedToIds.filter(id=>id!==jr.id):[...newTask.assignedToIds,jr.id]; setNewTask({...newTask,assignedToIds:ids,assignedTo:ids[0]||''}); }
                      else setNewTask({...newTask,assignedTo:jr.id,assignedToIds:[jr.id]});
                    }} style={{background:selected?'rgba(6,182,212,.18)':'rgba(15,23,42,.8)',borderColor:selected?'#22d3ee':'#1e293b',color:'#fff'}} className="w-full text-left p-3 rounded-xl border transition">
                      <div className="flex items-center justify-between"><div className="font-semibold">{jr.name}</div>{selected && <span className="text-[10px] font-extrabold text-cyan-200">✓ SELECTED</span>}</div>
                      <div className="text-[11px] text-slate-400">{jr.username} · {jr.designation||'Team Member'} · {jr.team||'General'}</div>
                    </button>;
                  })}
                  {juniors.filter(j=>`${j.name} ${j.username} ${j.designation||''} ${j.team||''}`.toLowerCase().includes(juniorSearch.toLowerCase())).length===0 && <div className="p-3 text-xs text-slate-500 text-center">No Junior found.</div>}
                </div>
                <p className="text-[11px] text-cyan-300 mt-1">{(newTask.assignmentMode==='group'?newTask.assignedToIds.length:(newTask.assignedTo?1:0))} member(s) selected{newTask.assignmentMode==='group'?' for this group task':''}.</p>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-300 mb-1 font-semibold">Priority Level *</label>
                  <select
                    value={newTask.priority}
                    onChange={(e) => setNewTask({ ...newTask, priority: e.target.value })}
                    className="w-full p-2.5 glass-input text-white font-semibold"
                  >
                    <option value="Low">Low</option>
                    <option value="Medium">Medium</option>
                    <option value="High">High</option>
                    <option value="Urgent">Urgent</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 mb-1 font-semibold">Deadline Date *</label>
                  <input
                    type="date"
                    value={newTask.deadline}
                    onChange={(e) => setNewTask({ ...newTask, deadline: e.target.value })}
                    className="w-full p-2.5 glass-input text-white font-semibold"
                  />
                </div>
              </div>

              <div className="flex justify-end space-x-2 pt-4 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAssignModal(false)}
                  className="px-4 py-2.5 rounded-xl bg-slate-800 text-slate-300 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-white font-bold shadow-lg"
                >
                  Assign Task
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
